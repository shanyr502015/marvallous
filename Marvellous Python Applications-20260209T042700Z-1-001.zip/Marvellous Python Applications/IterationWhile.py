i = 1

while(i < 5):
    print("Jay Ganesh")
    i = i + 1