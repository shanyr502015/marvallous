# Sequance

print("1")
print("2")
print("3")
print("4")
print("5")


#   range(Start, Stop, Step)
# range(10) -> 0 to 9
# range(2,7)    -> 2 to 6
# range(1,6)    -> 1 to 5
