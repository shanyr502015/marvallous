print("Enter your name : ")
Name = input()

print("Hello ",Name)

print("Enter your age : ")
Age = input()

print("Your age is : ",Age)