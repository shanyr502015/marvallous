# Scripting approach

No = 22

if (No % 2 == 0):
    print("It is Even")
else:
    print("It is Odd")