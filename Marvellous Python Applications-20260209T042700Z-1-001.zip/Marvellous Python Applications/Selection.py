no1 = 11
no2 = 21

if (no1 > no2):
    print("no1 is greater")
else:
    print("no2 is greater")