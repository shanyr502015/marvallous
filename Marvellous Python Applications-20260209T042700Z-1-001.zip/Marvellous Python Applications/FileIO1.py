def main():
    open("Demo.txt")

if __name__ == "__main__":
    main()