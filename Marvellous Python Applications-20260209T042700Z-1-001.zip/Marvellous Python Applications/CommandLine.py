import sys

print("Number of command line arguments are : ",len(sys.argv))