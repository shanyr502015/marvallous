class Demo:
    def __init__(self):
        self.No1 = 10       # public
        self._No2 = 20      # protected
        self.__No3 = 30     # private

obj = Demo()