print("Marvellous Infosystems")
print("Pune")
print("Maharashtra")
print("India")