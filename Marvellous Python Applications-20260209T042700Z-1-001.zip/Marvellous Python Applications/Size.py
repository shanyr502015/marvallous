import sys

No = 11987858576547456876776865654543543678778676564556         # int

Marks = 90.90   # float

Name = "Rahul"  # str

print(sys.getsizeof(No))
print(sys.getsizeof(Marks))
print(sys.getsizeof(Name))
