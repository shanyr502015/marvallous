Data = [10,20,30,40,50]

print(type(Data))       # list
print(len(Data))        # 5
print(Data)             # 10,20,30,40,50

print(Data[0])          # 10
print(Data[1])          # 20
print(Data[2])          # 30
print(Data[3])          # 40
print(Data[4])          # 50

