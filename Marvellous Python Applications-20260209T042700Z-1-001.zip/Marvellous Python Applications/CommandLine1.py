def main():
    No1 = int(input())
    No2 = int(input())

    print(No1 + No2)
    
if __name__ == "__main__":
    main()