# Numeric datatypes

print("------------------------------")
no = 11
print(no)
print(type(no))
print("------------------------------")

marks = 90.78
print(marks)
print(type(marks))
print("------------------------------")

x = 3+4j
print(x)
print(type(x))
print("------------------------------")
