print("-"*15)

arr = {10,20,30,40,10}
print(arr)
print(type(arr))

print("-"*15)

book = {"Name" : "Let us C", "Price" : 350.50, "Author" : "Y Kanetkar"}
print(book)
print(type(book))
print(book["Price"])

print("-"*15)
