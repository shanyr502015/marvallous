Data = [10,20,30,40,50]

for i in range(5):
    print(Data[i])

Sum = 0

for i in range(5):
    Sum = Sum + Data[i]

print("Summation is : ",Sum)