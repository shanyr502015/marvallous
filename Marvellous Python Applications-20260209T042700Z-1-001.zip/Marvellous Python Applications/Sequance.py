Value1 = [10,20,30,40,10]
print(Value1)
print(type(Value1))

Value2 = (10,20,30,40,10)
print(Value2)
print(type(Value2))

Value3 = {10,20,30,40,10}
print(Value3)
print(type(Value3))