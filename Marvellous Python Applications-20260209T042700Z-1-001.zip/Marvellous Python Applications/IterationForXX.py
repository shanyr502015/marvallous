# Sequance

print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")

print("------------------------------")

# Iteration

for i in range(4):
    print("Jay Ganesh")

# range(1,5)