Data = None

print(Data)
print(type(Data))