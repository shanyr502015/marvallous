Salary = 90000
City = "Pune"

print(Salary)
print(id(Salary))

print(City)
print(id(City))