No = 11
print(type(No))
print(id(No))

No = 78.90
print(type(No))
print(id(No))

No = "Hello"
print(type(No))
print(id(No))