# List - Duplicate
Value1 = [10,20,30,40,10]   
print(Value1[0])    # 10
Value1[2] = 35
print(Value1[2])

# Tuple - Duplicate
Value2 = (10,20,30,40,10)   
print(Value2[0])    # 10
# Value2[2] = 35    Error
print(Value2[2])

# Set - No Duplicate
Value3 = {10,20,30,40,10}   
#print(Value3[0])    # Error

