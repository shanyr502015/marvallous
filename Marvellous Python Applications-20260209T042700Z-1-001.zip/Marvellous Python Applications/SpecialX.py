if __name__ == "__main__":
    print("Self executabel file")
else:
    print("Module file")