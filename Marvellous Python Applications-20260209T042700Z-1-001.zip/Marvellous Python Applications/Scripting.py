No1 = 0
No2 = 0
Ans = 0

No1 = int(input("Enter first number : "))
No2 = int(input("Enter second number : "))

Ans = No1 + No2
print("Addition is : ",Ans)

Ans = No1 - No2
print("Substraction is : ",Ans)