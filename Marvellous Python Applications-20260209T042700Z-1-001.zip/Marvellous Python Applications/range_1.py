data = range(7)

print(data)
print(type(data))

test = range(3,9,2)
print(test)
print(type(test))
