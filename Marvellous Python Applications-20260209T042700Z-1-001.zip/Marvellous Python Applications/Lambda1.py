Add = lambda No1, No2 : No1 + No2

Ret = Add(11,10)
# Ret = 11 + 10

print("Addition is : ",Ret)