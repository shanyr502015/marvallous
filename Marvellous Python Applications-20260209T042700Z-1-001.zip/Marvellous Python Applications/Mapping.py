Information = {"Name":"Rahul", "Age":25, "City" : "Pune", "Marks" : 89.90}

print(type(Information))
print(Information)

print(Information["City"])