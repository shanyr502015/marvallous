Name = input("Enter your name : ")

print("Hello ",Name)

Age = input("Enter your age : ")

print("Your age is : ",Age)