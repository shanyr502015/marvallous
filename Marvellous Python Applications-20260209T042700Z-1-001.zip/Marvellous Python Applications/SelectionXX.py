no = 21

print(no + 2)   # 23
print(no - 2)   # 19
print(no * 2)   # 42
print(no / 2)   # 10.5
print(no ** 2)  # 441
print(no % 2)   # 1


