# Numeric

Age = 35
Marks = 89.78
Data = 8+7j

print(Age)

print("Age is : ",Age)
print("Marks : ",Marks)
print("Complex : ",Data)