No1 = 10
No2 = 11

Ans = No1 * No2

print("Multiplication is : ",Ans)