print("-"*15)

arr = [10,20,30,40,10]
print(arr)
print(type(arr))

print("-"*15)

brr = (10,20,30,40,10)
print(brr)
print(type(brr))

print("-"*15)
