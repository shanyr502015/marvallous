print("Enter first number : ")
No1 = int(input())

print("Enter second number : ")
No2 = int(input())

print(type(No1))
print(type(No2))

Ans = No1 + No2

print("Addition is : ",Ans)