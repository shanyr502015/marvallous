
print(__name__)